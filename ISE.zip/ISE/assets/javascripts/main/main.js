
let day = (date, cal) =>{

  schedule.filter(i => i.date == date)
          .map(e => {

          })
}
