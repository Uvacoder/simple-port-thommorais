// activing the smoothScroll Plugin
SmoothScroll({
    // Acceleration
    accelerationDelta: 50,  // 50
    accelerationMax: 3,   // 3
    fixedBackground   : true, 
    touchpadSupport   : true, // ignore touchpad by default
})

