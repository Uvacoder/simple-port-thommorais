import Swiper from './vendors/swiper.esm'
export default Swiper
