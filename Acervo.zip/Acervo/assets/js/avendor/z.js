const doc = document,
	dd = doc.querySelectorAll.bind(doc),
	d = doc.querySelector.bind(doc),
	body = doc.body




function datePicker(){

	let startDate,
		endDate,
		updateStartDate = function(){
			startPicker.setStartRange(startDate)
			endPicker.setStartRange(startDate)
			endPicker.setMinDate(startDate)
		},
		updateEndDate = function(){
			startPicker.setEndRange(endDate)
			startPicker.setMaxDate(endDate)
			endPicker.setEndRange(endDate)
		},
		startPicker = new Pikaday({
			field: document.getElementById('startDate'),
			maxDate: new Date(2020, 12, 31),
			yearRange: 80,
			format: 'DD/MM/YYYY',
			toString(date, format) {
				const day = date.getDate();
				const month = date.getMonth() + 1;
				const year = date.getFullYear();
				return `${day}/${month}/${year}`;
			},
			onSelect: function(){
				startDate = this.getDate()
				updateStartDate()
			}
		}),
		endPicker = new Pikaday({
			field: document.getElementById('endDate'),
			maxDate: new Date(2020, 12, 31),
			yearRange: [1700, 2050],
			format: 'D/M/YYYY',
			toString(date, format) {
				const day = date.getDate();
				const month = date.getMonth() + 1;
				const year = date.getFullYear();
				return `${day}/${month}/${year}`;
			},

			onSelect: function(){
				endDate = this.getDate()
				updateEndDate()
			}
		}),
		
		_startDate = startPicker.getDate(),
		_endDate = endPicker.getDate()

		if (_startDate) {
			startDate = _startDate
			updateStartDate()
		}

		if (_endDate) {
			endDate = _endDate
			updateEndDate()
		}

}
class DropDownSearch {

	constructor() {

		this.hasDropDown = Array.from(dd('input.has-drop-down'))
		this.dropDowns = Array.from(dd('.drop-down-options'))
		this.flag = false

		this.binder()
	}

	binder() {

		body.addEventListener('click', this._clickOut.bind(this), true)
		this.hasDropDown.map(e => e.addEventListener('focus', this._showDropDown.bind(this), true))
	}

	_showDropDown(event) {

		this.flag = true
		this.dropDowns.map(e => { e.style.display = 'none' })
		d(`[data-drop='${event.target.id}']`).style.display = 'block'
	}

	hideDropDown() {

		this.flag = false
		this.dropDowns.map(e => { e.style.display = 'none' })
	}

	_clickOut(e) {
		let allParents = getParents(e.target.parentNode, '.has-drop-down') || getParents(e.target.parentNode, '.pika-lendar') || false
		this.flag && !allParents && this.hideDropDown()
	}
}


class Modo {

	constructor() {

		this.mode = d('.mode')
		this.modo = Array.from(dd('.modo'))
		this.input = Array.from(this.mode.querySelectorAll('input'))

		this.binder()
	}

	binder() {

		this.input.map(e => {
			e.addEventListener('change', this.changeModo.bind(this), true)
			if (e.checked) d(`#${e.dataset.modo}`).style.display = 'block'
		})

	}

	changeModo(e) {

		this.modo.map(e => {
			e.style.display = 'none'
		})

		if (e.target.checked) d(`#${e.target.dataset.modo}`).style.display = 'block'
	}

}

class UpdateSearchItems {

	constructor() {

		this.modo = Array.from(dd('.modo'))

		this.input

		this.dropDown  = new DropDownSearch()
		this.changeModo = new Modo()


		this.byDate = Array.from(dd('.by-date input'))
		this.byDateInput = d('#selecione-periodo')
		
		this.day = d(`[name="days"]`)
		this.month = d(`[name="month"]`)
		this.year = d(`[name="year"]`)

		this.byJornalInput = d('#selecione-jornais')
		this.jornals = Array.from(dd(`[name="jornais"]`))

		this._bind()
	}

	_bind() {

		// this.modo.map(e => {
		// 	e.querySelector('.buscar').addEventListener('click', this.getValue.bind(this), true)
		// })

		this.byDate.map(e => {
			e.addEventListener('change', this.getValue.bind(this), true)
		})

		this.jornals.map(e => {
			e.addEventListener('change', this.getValue.bind(this), true)
		})

		this.day.addEventListener('change', () => {
			let max =  parseInt(this.day.max)
			if (this.day.value > max) this.day.value = max
				this.month.value && this._hasEnoughtDays()

			this._removeError(this.day)

		})

		this.month.addEventListener('change', () =>{
			let max = parseInt(this.month.max)
			if (this.month.value > max) this.month.value = max
				this.day.value && this._hasEnoughtDays()
			
			this._removeError(this.month)
		})

	}

	_hasEnoughtDays(){
		let days = getDaysInMonth(parseInt(this.month.value))
		if(this.day.value > days) this.day.value = days
	}

	validation(day, month, year){

		day > getDaysInMonth(month, year) && this._printError('outOfDays')
		month > 12 && this._printError('outOfMonths')
		!day && this._printError('emptyDay')
		!month && this._printError('emptyMonth')

		return day && month
	}

	_printError(which){

		switch(which){
			case 'outOfDays':
				this.day.classList.add('error')
				break
			case 'emptyDay':
				this.day.classList.add('error')
				break
			case 'emptyMonth':
				this.month.classList.add('error')
				break
			default:
				throw new Error('What fuck?')
			
		}

	}

	_removeError(el){
		el.classList.remove('error')
	}

	getValue(e) {
		
		this.input = Array.from(e.target.parentNode.querySelectorAll('input'))
		
		let porPeriodo = this.input.includes(d('#startDate')) && this.input.includes(d('#startDate'))
			porPeriodo && 
			this.updateValueByDate(`${d('#startDate').value} - ${d('#endDate').value}`)

		let porDia = this.input.includes(this.day) && this.input.includes(this.month)
			porDia && 
			this.validation(this.day.value, this.month.value, this.year.value) && 
			this.updateValueByDate(`${this.day.value}/${this.month.value}/${this.year.value}`)

		e.target.type == 'radio' && this.updateValueByDate(e.target.value)

		let jornal = this.input.includes(d(`[name="jornais"]`)) 
			jornal && e.target.checked && this.updateValueByJornal(e.target.value)
			jornal && !e.target.checked && this.updateValueByJornal('Todos os Jornais')

	}

	updateValueByDate(value) {
		
		this.byDateInput.value = value
		this.dropDown.hideDropDown()
	}

	updateValueByJornal(value) {
		console.log('hey')
		this.byJornalInput.value = value
		this.dropDown.hideDropDown()
	}


}


doc.addEventListener("DOMContentLoaded", () => {

	datePicker()
	new UpdateSearchItems()

	/**
	 * Carousel
	**/
	const carousel =  d('.main-carousel') || false

	carousel && 
	new Flickity( carousel, {
		cellAlign: 'left',
		contain: true,
		imagesLoaded: true,
		freeScroll: false,
		prevNextButtons: false,
		groupCells: true
	})


	let menuOpner = d('#menu-trigger') 
	let menu = d('.hidden-menu')
	let menuCloser = menu.querySelector('.close') 

	menuOpner.addEventListener('click', ()=>{
		 classie.toggle( menu, 'menu-active' )
	})
	
	menuCloser.addEventListener('click', ()=>{
		 classie.toggle( menu, 'menu-active' )
	})

})
/**
 * Get all DOM element up the tree that contain a class, ID, or data attribute
 * @param  {Node} elem The base element
 * @param  {String} selector The class, id, data attribute, or tag to look for
 * @return {Array} Null if no match
 */
function getParents(elem, selector) {

    var parents = []
    var firstChar
    if ( selector ) {
        firstChar = selector.charAt(0)
    }

    // Get matches
    for ( ; elem && elem !== document; elem = elem.parentNode ) {
        if ( selector ) {

            // If selector is a class
            if ( firstChar === '.' ) {
                if ( elem.classList.contains( selector.substr(1) ) ) {
                    parents.push( elem )
                }
            }

            // If selector is an ID
            if ( firstChar === '#' ) {
                if ( elem.id === selector.substr(1) ) {
                    parents.push( elem )
                }
            }

            // If selector is a data attribute
            if ( firstChar === '[' ) {
                if ( elem.hasAttribute( selector.substr(1, selector.length - 1) ) ) {
                    parents.push( elem )
                }
            }

            // If selector is a tag
            if ( elem.tagName.toLowerCase() === selector ) {
                parents.push( elem )
            }

        } else {
            parents.push( elem )
        }

    }

    // Return parents if any exist
    if ( parents.length === 0 ) {
        return null
    } else {
        return parents
    }

}


/**
    * Check if month has 30 or 31 days, 
    *@param {Number} month to check
    *@param {Number} year of the month 
    *@param {Number} number of the days of the month
 */
 
const date = new Date()
const year = date.getFullYear()

function getDaysInMonth(m, y = year) {
    return m===2 ? y & 3 || !(y % 25) && y & 15 ? 28 : 29 : 30 + (m +(m >> 3) & 1)
}


/*!
 * classie v1.0.1
 * class helper functions
 * from bonzo https://github.com/ded/bonzo
 * MIT license
 * 
 * classie.has( elem, 'my-class' ) -> true/false
 * classie.add( elem, 'my-new-class' )
 * classie.remove( elem, 'my-unwanted-class' )
 * classie.toggle( elem, 'my-class' )
 */

/*jshint browser: true, strict: true, undef: true, unused: true */
/*global define: false, module: false */

( function( window ) {

'use strict';

// class helper functions from bonzo https://github.com/ded/bonzo

function classReg( className ) {
  return new RegExp("(^|\\s+)" + className + "(\\s+|$)");
}


// classList support for class management
// altho to be fair, the api sucks because it won't accept multiple classes at once
var hasClass, addClass, removeClass;

if ( 'classList' in document.documentElement ) {
  hasClass = function( elem, c ) {
    return elem.classList.contains( c );
  };
  addClass = function( elem, c ) {
    elem.classList.add( c );
  };
  removeClass = function( elem, c ) {
    elem.classList.remove( c );
  };
}
else {
  hasClass = function( elem, c ) {
    return classReg( c ).test( elem.className );
  };
  addClass = function( elem, c ) {
    if ( !hasClass( elem, c ) ) {
      elem.className = elem.className + ' ' + c;
    }
  };
  removeClass = function( elem, c ) {
    elem.className = elem.className.replace( classReg( c ), ' ' );
  };
}

function toggleClass( elem, c ) {
  var fn = hasClass( elem, c ) ? removeClass : addClass;
  fn( elem, c );
}

var classie = {
  // full names
  hasClass: hasClass,
  addClass: addClass,
  removeClass: removeClass,
  toggleClass: toggleClass,
  // short names
  has: hasClass,
  add: addClass,
  remove: removeClass,
  toggle: toggleClass
};

// transport
if ( typeof define === 'function' && define.amd ) {
  // AMD
  define( classie );
} else if ( typeof exports === 'object' ) {
  // CommonJS
  module.exports = classie;
} else {
  // browser global
  window.classie = classie;
}

})( window );