class DropDownSearch {

	constructor() {

		this.hasDropDown = Array.from(dd('input.has-drop-down'))
		this.dropDowns = Array.from(dd('.drop-down-options'))
		this.flag = false

		this.binder()
	}

	binder() {

		body.addEventListener('click', this._clickOut.bind(this), true)
		this.hasDropDown.map(e => e.addEventListener('focus', this._showDropDown.bind(this), true))
	}

	_showDropDown(event) {

		this.flag = true
		this.dropDowns.map(e => { e.style.display = 'none' })
		d(`[data-drop='${event.target.id}']`).style.display = 'block'
	}

	hideDropDown() {

		this.flag = false
		this.dropDowns.map(e => { e.style.display = 'none' })
	}

	_clickOut(e) {
		let allParents = getParents(e.target.parentNode, '.has-drop-down') || getParents(e.target.parentNode, '.pika-lendar') || false
		this.flag && !allParents && this.hideDropDown()
	}
}


class Modo {

	constructor() {

		this.mode = d('.mode')
		this.modo = Array.from(dd('.modo'))
		this.input = Array.from(this.mode.querySelectorAll('input'))

		this.binder()
	}

	binder() {

		this.input.map(e => {
			e.addEventListener('change', this.changeModo.bind(this), true)
			if (e.checked) d(`#${e.dataset.modo}`).style.display = 'block'
		})

	}

	changeModo(e) {

		this.modo.map(e => {
			e.style.display = 'none'
		})

		if (e.target.checked) d(`#${e.target.dataset.modo}`).style.display = 'block'
	}

}

class UpdateSearchItems {

	constructor() {

		this.modo = Array.from(dd('.modo'))

		this.input

		this.dropDown  = new DropDownSearch()
		this.changeModo = new Modo()


		this.byDate = Array.from(dd('.by-date input'))
		this.byDateInput = d('#selecione-periodo')
		
		this.day = d(`[name="days"]`)
		this.month = d(`[name="month"]`)
		this.year = d(`[name="year"]`)

		this.byJornalInput = d('#selecione-jornais')
		this.jornals = Array.from(dd(`[name="jornais"]`))

		this._bind()
	}

	_bind() {

		// this.modo.map(e => {
		// 	e.querySelector('.buscar').addEventListener('click', this.getValue.bind(this), true)
		// })

		this.byDate.map(e => {
			e.addEventListener('change', this.getValue.bind(this), true)
		})

		this.jornals.map(e => {
			e.addEventListener('change', this.getValue.bind(this), true)
		})

		this.day.addEventListener('change', () => {
			let max =  parseInt(this.day.max)
			if (this.day.value > max) this.day.value = max
				this.month.value && this._hasEnoughtDays()

			this._removeError(this.day)

		})

		this.month.addEventListener('change', () =>{
			let max = parseInt(this.month.max)
			if (this.month.value > max) this.month.value = max
				this.day.value && this._hasEnoughtDays()
			
			this._removeError(this.month)
		})

	}

	_hasEnoughtDays(){
		let days = getDaysInMonth(parseInt(this.month.value))
		if(this.day.value > days) this.day.value = days
	}

	validation(day, month, year){

		day > getDaysInMonth(month, year) && this._printError('outOfDays')
		month > 12 && this._printError('outOfMonths')
		!day && this._printError('emptyDay')
		!month && this._printError('emptyMonth')

		return day && month
	}

	_printError(which){

		switch(which){
			case 'outOfDays':
				this.day.classList.add('error')
				break
			case 'emptyDay':
				this.day.classList.add('error')
				break
			case 'emptyMonth':
				this.month.classList.add('error')
				break
			default:
				throw new Error('What fuck?')
			
		}

	}

	_removeError(el){
		el.classList.remove('error')
	}

	getValue(e) {
		
		this.input = Array.from(e.target.parentNode.querySelectorAll('input'))
		
		let porPeriodo = this.input.includes(d('#startDate')) && this.input.includes(d('#startDate'))
			porPeriodo && 
			this.updateValueByDate(`${d('#startDate').value} - ${d('#endDate').value}`)

		let porDia = this.input.includes(this.day) && this.input.includes(this.month)
			porDia && 
			this.validation(this.day.value, this.month.value, this.year.value) && 
			this.updateValueByDate(`${this.day.value}/${this.month.value}/${this.year.value}`)

		e.target.type == 'radio' && this.updateValueByDate(e.target.value)

		let jornal = this.input.includes(d(`[name="jornais"]`)) 
			jornal && e.target.checked && this.updateValueByJornal(e.target.value)
			jornal && !e.target.checked && this.updateValueByJornal('Todos os Jornais')

	}

	updateValueByDate(value) {
		
		this.byDateInput.value = value
		this.dropDown.hideDropDown()
	}

	updateValueByJornal(value) {
		console.log('hey')
		this.byJornalInput.value = value
		this.dropDown.hideDropDown()
	}


}
