function datePicker(){

	let startDate,
		endDate,
		updateStartDate = function(){
			startPicker.setStartRange(startDate)
			endPicker.setStartRange(startDate)
			endPicker.setMinDate(startDate)
		},
		updateEndDate = function(){
			startPicker.setEndRange(endDate)
			startPicker.setMaxDate(endDate)
			endPicker.setEndRange(endDate)
		},
		startPicker = new Pikaday({
			field: document.getElementById('startDate'),
			maxDate: new Date(2020, 12, 31),
			yearRange: 80,
			format: 'DD/MM/YYYY',
			toString(date, format) {
				const day = date.getDate();
				const month = date.getMonth() + 1;
				const year = date.getFullYear();
				return `${day}/${month}/${year}`;
			},
			onSelect: function(){
				startDate = this.getDate()
				updateStartDate()
			}
		}),
		endPicker = new Pikaday({
			field: document.getElementById('endDate'),
			maxDate: new Date(2020, 12, 31),
			yearRange: [1700, 2050],
			format: 'D/M/YYYY',
			toString(date, format) {
				const day = date.getDate();
				const month = date.getMonth() + 1;
				const year = date.getFullYear();
				return `${day}/${month}/${year}`;
			},

			onSelect: function(){
				endDate = this.getDate()
				updateEndDate()
			}
		}),
		
		_startDate = startPicker.getDate(),
		_endDate = endPicker.getDate()

		if (_startDate) {
			startDate = _startDate
			updateStartDate()
		}

		if (_endDate) {
			endDate = _endDate
			updateEndDate()
		}

}