const doc = document,
	dd = doc.querySelectorAll.bind(doc),
	d = doc.querySelector.bind(doc),
	body = doc.body



