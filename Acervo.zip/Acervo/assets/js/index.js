doc.addEventListener("DOMContentLoaded", () => {

	datePicker()
	new UpdateSearchItems()

	/**
	 * Carousel
	**/
	const carousel =  d('.main-carousel') || false

	carousel && 
	new Flickity( carousel, {
		cellAlign: 'left',
		contain: true,
		imagesLoaded: true,
		freeScroll: false,
		prevNextButtons: false,
		groupCells: true
	})


	let menuOpner = d('#menu-trigger') 
	let menu = d('.hidden-menu')
	let menuCloser = menu.querySelector('.close') 

	menuOpner.addEventListener('click', ()=>{
		 classie.toggle( menu, 'menu-active' )
	})
	
	menuCloser.addEventListener('click', ()=>{
		 classie.toggle( menu, 'menu-active' )
	})

})